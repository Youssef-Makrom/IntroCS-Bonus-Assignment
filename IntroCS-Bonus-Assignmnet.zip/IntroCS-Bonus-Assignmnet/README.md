# IntroCS-Bonus-Assignment

Practice for pulling

Pull beofre pushing 
